#!/bin/sh

#  ci_pre_xcodebuild.sh
#  UXCamFramework
#
#  Created by Ankit Karna on 08/08/2023.
#  Copyright © 2023 UXCam. All rights reserved.

set -e

DATE=$(date +'%m%d%Y%H%M')

PROJECT_FILE=UXCam/UXCamFramework.xcodeproj/project.pbxproj
BUILD_NUMBER=${DATE}

VERSION_NUMBER=$CI_TAG

# Update the MARKETING_VERSION and CURRENT_PROJECT_VERSION values in the project file
sed -i "" "s/CURRENT_PROJECT_VERSION = .*/CURRENT_PROJECT_VERSION = $BUILD_NUMBER;/g" "$PROJECT_FILE"
if [[ -n $VERSION_NUMBER ]];
then
    sed -i "" "s/MARKETING_VERSION = .*/MARKETING_VERSION = $VERSION_NUMBER;/g" "$PROJECT_FILE"
fi


