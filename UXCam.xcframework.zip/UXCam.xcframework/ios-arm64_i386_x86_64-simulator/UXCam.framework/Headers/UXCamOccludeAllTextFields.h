//
//  UXCamOccludeAllTextFields.h
//  UXCam
//
//  Created by Ankit Karna on 22/02/2022.
//  Copyright © 2022 UXCam. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UXCam/UXCamOcclusionSetting.h>

NS_ASSUME_NONNULL_BEGIN

@interface UXCamOccludeAllTextFields : NSObject<UXCamOcclusionSetting>

@end

NS_ASSUME_NONNULL_END
